import express from "express";
import {
  createComplaint,
  getAllComplaints,
  getComplaintsByTenantId,
  getComplaintById,
  updateComplaintStatus,
  deleteComplaint,
} from "../controllers/complaint.controller.js";

import { authenticateToken, authorizeRoles } from "../middleware/auth.middleware.js";
import { validateBody } from "../middleware/validation.middleware.js"; // <-- đúng tên file mà bạn dùng
import { asyncHandler } from "../middleware/error.middleware.js"; // nếu bạn có asyncHandler wrapper

import {
  createComplaintSchema,
  updateComplaintStatusSchema,
} from "../validations/complaint.validation.js";

const router = express.Router();

// Test ping
router.get("/_ping", (req, res) => res.json({ ok: true, message: "complaint route alive" }));

// Create complaint (tenant)
router.post(
  "/",
  authenticateToken,
  validateBody(createComplaintSchema),
  asyncHandler(createComplaint)
);

// Get all complaints (admin)
router.get(
  "/",
  authenticateToken,
  authorizeRoles ? authorizeRoles("ADMIN") : (req, res, next) => next(),
  asyncHandler(getAllComplaints)
);

// Get complaints by tenantId (tenant)
router.get(
  "/tenant/:tenantId",
  authenticateToken,
  asyncHandler(getComplaintsByTenantId)
);

// Get complaint by id
router.get(
  "/:id",
  authenticateToken,
  asyncHandler(getComplaintById)
);

// Update complaint status (admin)
router.put(
  "/:id/status",
  authenticateToken,
  authorizeRoles ? authorizeRoles("ADMIN") : (req, res, next) => next(),
  validateBody(updateComplaintStatusSchema),
  asyncHandler(updateComplaintStatus)
);

// Delete complaint (admin)
router.delete(
  "/:id",
  authenticateToken,
  authorizeRoles ? authorizeRoles("ADMIN") : (req, res, next) => next(),
  asyncHandler(deleteComplaint)
);

export default router;
